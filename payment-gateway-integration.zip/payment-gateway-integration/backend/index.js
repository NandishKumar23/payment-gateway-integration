const app=require("express")()
const path=require("path")
const short=require("shortid")
const razorpay=require("razorpay")
const shortid = require("shortid")
const cors=require("cors")
app.use(cors("*"))
var instance =new razorpay({
    key_id:  "rzp_test_ZykJuQmVB3bIVF" ,
    key_secret: "kncgpHgUcEpuBZOOCR3UckTu" ,
})
app.get('/logo.svg',async function(req,res){
    res.sendFile(path.join(__dirname,'logo.svg'))
}) 
app.post("/razorpay",async function(req,res){
 
   const currency="INR"
   const options={
    amount:1000,
    currency:currency ,
    receipt: shortid.generate(),
    payment_capture :1,
   }
   const response=  await  instance.orders.create(options)
   console.log(response)
    
    res.status(200).send(JSON.stringify({
        id:response.id,
        currency:response.currency,
        amount:response.amount
    }));
})
app.listen(3001,function(){
  console.log("Server ready at port 3001");
})